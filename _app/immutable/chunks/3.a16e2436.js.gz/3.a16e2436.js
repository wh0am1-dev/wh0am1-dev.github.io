import{default as t}from"../entry/cv-page.svelte.3cb4ba59.js";export{t as component};
