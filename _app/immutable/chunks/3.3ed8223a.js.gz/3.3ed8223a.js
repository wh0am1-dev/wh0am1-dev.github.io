import{default as t}from"../entry/cv-page.svelte.1580171a.js";export{t as component};
