const r=!0,e="always",t=Object.freeze(Object.defineProperty({__proto__:null,prerender:!0,trailingSlash:e},Symbol.toStringTag,{value:"Module"}));export{t as _,r as p,e as t};
