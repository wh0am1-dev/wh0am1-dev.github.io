import{default as t}from"../entry/_error.svelte.976b7c9d.js";export{t as component};
