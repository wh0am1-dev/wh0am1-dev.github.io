import{default as t}from"../entry/cv-page.svelte.5b2c2e34.js";export{t as component};
