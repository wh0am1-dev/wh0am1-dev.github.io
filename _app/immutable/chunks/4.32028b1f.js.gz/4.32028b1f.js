import{default as t}from"../entry/oss-page.svelte.5432e3dc.js";export{t as component};
