import{default as t}from"../entry/cv-page.svelte.03240c3a.js";export{t as component};
