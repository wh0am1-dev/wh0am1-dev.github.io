import{default as t}from"../entry/_error.svelte.c80eec92.js";export{t as component};
