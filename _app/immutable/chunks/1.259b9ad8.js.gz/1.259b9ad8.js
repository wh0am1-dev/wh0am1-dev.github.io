import{default as t}from"../entry/_error.svelte.2b1fc74b.js";export{t as component};
