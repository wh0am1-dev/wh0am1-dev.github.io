import{default as t}from"../entry/_page.svelte.a2f17ab7.js";export{t as component};
