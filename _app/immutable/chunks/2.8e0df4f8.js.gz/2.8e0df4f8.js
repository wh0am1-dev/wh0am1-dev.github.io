import{default as t}from"../entry/_page.svelte.78f9d145.js";export{t as component};
