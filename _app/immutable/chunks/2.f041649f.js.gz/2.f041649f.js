import{default as t}from"../entry/_page.svelte.a2cd9679.js";export{t as component};
