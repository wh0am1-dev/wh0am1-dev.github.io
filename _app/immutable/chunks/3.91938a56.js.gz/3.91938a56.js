import{default as t}from"../entry/cv-page.svelte.b0b5a716.js";export{t as component};
