import{default as t}from"../entry/oss-page.svelte.d351dca5.js";export{t as component};
