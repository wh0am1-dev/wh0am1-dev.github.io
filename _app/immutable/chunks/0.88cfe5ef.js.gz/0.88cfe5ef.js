import{_ as r}from"./_layout.79cb23d1.js";import{default as t}from"../entry/_layout.svelte.403e4449.js";export{t as component,r as universal};
