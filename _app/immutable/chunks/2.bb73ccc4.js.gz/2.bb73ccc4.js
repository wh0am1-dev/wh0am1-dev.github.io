import{default as t}from"../entry/_page.svelte.bcb47f4e.js";export{t as component};
