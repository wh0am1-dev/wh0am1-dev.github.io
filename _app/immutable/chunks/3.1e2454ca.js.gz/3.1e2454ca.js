import{default as t}from"../entry/cv-page.svelte.792434c0.js";export{t as component};
