import{default as t}from"../entry/_page.svelte.1770a545.js";export{t as component};
