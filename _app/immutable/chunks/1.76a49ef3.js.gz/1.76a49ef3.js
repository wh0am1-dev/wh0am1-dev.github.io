import{default as t}from"../entry/_error.svelte.50108c16.js";export{t as component};
