import{default as t}from"../entry/oss-page.svelte.ec30453e.js";export{t as component};
