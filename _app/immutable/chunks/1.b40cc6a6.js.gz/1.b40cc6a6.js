import{default as t}from"../entry/_error.svelte.4a4d9435.js";export{t as component};
