import{default as t}from"../entry/oss-page.svelte.ffcdc86a.js";export{t as component};
