import{default as t}from"../entry/oss-page.svelte.0de3aa29.js";export{t as component};
