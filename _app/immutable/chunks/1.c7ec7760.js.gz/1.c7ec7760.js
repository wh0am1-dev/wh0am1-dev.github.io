import{default as t}from"../entry/_error.svelte.bc9341d7.js";export{t as component};
