import{default as t}from"../entry/_page.svelte.b94d1d0c.js";export{t as component};
