import{default as t}from"../entry/oss-page.svelte.8403325d.js";export{t as component};
